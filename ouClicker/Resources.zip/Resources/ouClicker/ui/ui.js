(function() {

	ouClicker.ui = {};
	ouClicker.ui.configTab = {};
})();
Ti.include(
'/ouClicker/ui/available.js'
,'/ouClicker/ui/question.js'
,'/ouClicker/ui/thanks.js'
,'/ouClicker/ui/login.js'
,'/ouClicker/ui/forbidden.js'
);