(function() {

	ouClicker.model = {};
	
})();
Ti.include(
'/ouClicker/model/table.js'
);