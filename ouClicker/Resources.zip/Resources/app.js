Ti.include(
	'/ouClicker/clicker.js'
);


ouClicker.app.mainWindow = ouClicker.ui.getAvailableWindow();
ouClicker.app.mainWindow.open();



